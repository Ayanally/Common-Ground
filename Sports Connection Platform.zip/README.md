
  # Sports Connection Platform

  This is a code bundle for Sports Connection Platform. The original project is available at https://www.figma.com/design/D66OPqqrWqcgPQ7hBAy3jH/Sports-Connection-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  